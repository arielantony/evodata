<?php
/*************************
  Coppermine Photo Gallery
  ************************
  Copyright (c) 2003-2005 Coppermine Dev Team
  v1.1 originaly written by Gregory DEMAR

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.
  ********************************************
  Coppermine version: 1.4.2
  $Source: /cvsroot/coppermine/devel/plugins/sample/configuration.php,v $
  $Revision: 1.2 $
  $Author: gaugau $
  $Date: 2005/10/25 01:16:09 $
**********************************************/

$name='Sample Plugin';
$description='This is a sample plugin.';
$author='Coppermine Development Team';
$version='1.0';
?>
